* Since this is only a conky theme, consider submitting issues against the [project itself](https://github.com/brndnmtthws/conky).
